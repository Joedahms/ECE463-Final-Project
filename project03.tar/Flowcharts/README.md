# Flowcharts

This folder contains my flowcharts for the client and server programs I have written.   
The diagrams are constructed using [draw.io](https://app.diagrams.net/).

## client-server-communication
This diagram shows how the client and server communicate and how they go about exchanging files with each other.  

## client-main & server-main
The client main and server main diagrams show more specific details about the operation of each program alone.
