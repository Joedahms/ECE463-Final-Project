# src
Contained within this directory is all the source code to our project. It is written entirely in  
C using the Berkeley sockets.

## client_code
This directory contains the source code for the client.

## server_code
This directory contains the source code for the server.

## common
This directory contains functions used by both the client and the server.
